# Boat Pro USA Build Test Report

**Test date:** July 22, 2026  
**Build:** BoatProUSA Website 2026 — Apps Script Endpoint Configured

## Passed checks

- The production endpoint is configured in `assets/config.js`.
- The example newsletter form uses the same `/exec` endpoint.
- Newsletter forms use native HTTPS POST submission to Google Apps Script.
- The Netlify Content Security Policy allows form submission to `https://script.google.com`.
- Honeypot, consent, first-name, last-name, email, and source fields match the supplied Apps Script request parser.
- Internal pages and required assets resolve inside the package.
- Premium tutorials and guides contain no direct public download URLs.
- Stripe checkout remains disabled until real checkout links and secure access verification are implemented.

## Live endpoint check — failed

Configured endpoint:

`https://script.google.com/macros/s/AKfycbwSLD7gmeiUItt2wJVozJU1AX_2NzJwrnynRCxEvA_LhcRYIxhAtXXd1Oi2tzUImpYV8A/exec`

Google returned:

`SyntaxError: Identifier 'SHEET_NAME' has already been declared (line 1, file "Untitled 2")`

This failure occurs inside the deployed Apps Script project before the website request can be processed. The site configuration is correct, but the Google deployment must be repaired and redeployed.

## Required before public launch

1. Follow `google-apps-script/APPS_SCRIPT_DEPLOYMENT_REPAIR.md`.
2. Redeploy a new Apps Script version.
3. Confirm the endpoint displays “The subscriber service is running.”
4. Submit a real test signup and verify the CRM row, guide email, redirect, and unsubscribe workflow.

Paid membership must remain disabled until Stripe webhook verification and protected member delivery are implemented.
