# Boat Pro USA Google Apps Script Deployment Repair

**Configured endpoint:** `https://script.google.com/macros/s/AKfycbwSLD7gmeiUItt2wJVozJU1AX_2NzJwrnynRCxEvA_LhcRYIxhAtXXd1Oi2tzUImpYV8A/exec`  
**Verification date:** July 22, 2026

## Current error

Google returns:

`SyntaxError: Identifier 'SHEET_NAME' has already been declared (line 1, file "Untitled 2")`

This is a Google Apps Script project compilation error. The website cannot submit a subscriber until the deployed project compiles.

## Repair steps

1. Open the Google Apps Script project associated with the endpoint.
2. In the file list, open **Untitled 2**.
3. Find `const SHEET_NAME`, `let SHEET_NAME`, or `var SHEET_NAME`.
4. Search the entire Apps Script project for every declaration of `SHEET_NAME`.
5. Remove obsolete duplicate files or duplicate declarations. The supplied `Code.gs` does not require a global `SHEET_NAME`; it uses the `BOAT_PRO` configuration object instead.
6. For the cleanest repair, keep a backup, delete obsolete `.gs` files, and replace the project code with the supplied `Code.gs` and `appsscript.json`.
7. Run `setupBoatPro()` once and approve Google permissions.
8. Confirm the configured spreadsheet contains the tabs `Subscribers`, `Email_Log`, and `Unsubscribes`.
9. Choose **Deploy → Manage deployments → Edit**. Select **New version**, execute as **Me**, allow access to **Anyone**, and deploy.
10. Open the endpoint in a private browser window. It should say: “The subscriber service is running.”
11. Test one real signup from the website. Verify the CRM row, attached 2026 guide, thank-you redirect, duplicate protection, and unsubscribe link.

## Website configuration

The website already contains this setting in `assets/config.js`:

```javascript
appsScriptUrl: "https://script.google.com/macros/s/AKfycbwSLD7gmeiUItt2wJVozJU1AX_2NzJwrnynRCxEvA_LhcRYIxhAtXXd1Oi2tzUImpYV8A/exec"
```

No website URL change is required unless Google creates a different deployment URL.
