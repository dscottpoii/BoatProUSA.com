/**
 * Boat Pro USA newsletter signup and guide-delivery web app.
 *
 * Before deployment:
 * 1. Paste this file into a new Google Apps Script project.
 * 2. Add appsscript.json.
 * 3. Run setupBoatPro() once and approve permissions.
 * 4. Deploy as a Web app: execute as Me; access Anyone.
 */

const BOAT_PRO = Object.freeze({
  SPREADSHEET_ID: '13XSLWLfjOmSd9KhvW7BoS1SNaHbCgMgvAJSCQofZz1g',
  GUIDE_FILE_ID: '1lKNfxDKJxN-zOeXcmiVevKvSPZj2GopP',
  SUBSCRIBERS_SHEET: 'Subscribers',
  EMAIL_LOG_SHEET: 'Email_Log',
  UNSUBSCRIBES_SHEET: 'Unsubscribes',
  SITE_URL: 'https://BoatProUSA.com',
  THANK_YOU_URL: 'https://BoatProUSA.com/thank-you.html',
  SUPPORT_EMAIL: 'Info@BoatProUSA.com',
  SENDER_NAME: 'Boat Pro USA',
  GUIDE_NAME: "2026 Annapolis Boat Shows — Do's & Don'ts Guide",
  MAX_DAILY_SENDS: 90,
  EMAIL_COOLDOWN_SECONDS: 3600,
  MAX_NAME_LENGTH: 80,
  MAX_SOURCE_LENGTH: 120,
  TIME_ZONE: 'America/New_York'
});

const COL = Object.freeze({
  ID: 1,
  FIRST: 2,
  LAST: 3,
  EMAIL: 4,
  STATUS: 5,
  SOURCE: 6,
  CONSENT: 7,
  CONSENT_AT: 8,
  SIGNUP_AT: 9,
  GUIDE_SENT: 10,
  GUIDE_SENT_AT: 11,
  TOKEN: 12,
  UNSUB_AT: 13,
  UPDATED_AT: 14,
  ERROR: 15
});

const SHEET_HEADERS = Object.freeze({
  Subscribers: Object.freeze([
    'Subscriber ID', 'First Name', 'Last Name', 'Email', 'Status', 'Source',
    'Consent', 'Consent Timestamp', 'Signup Timestamp', 'Guide Sent',
    'Guide Sent Timestamp', 'Unsubscribe Token', 'Unsubscribe Timestamp',
    'Last Updated', 'Error'
  ]),
  Email_Log: Object.freeze([
    'Timestamp', 'Email', 'Event', 'Status', 'Message ID', 'Details'
  ]),
  Unsubscribes: Object.freeze([
    'Timestamp', 'Email', 'Token', 'Source', 'Status'
  ])
});


function setupBoatPro() {
  const spreadsheet = SpreadsheetApp.openById(BOAT_PRO.SPREADSHEET_ID);
  spreadsheet.setSpreadsheetTimeZone(BOAT_PRO.TIME_ZONE);

  Object.keys(SHEET_HEADERS).forEach(function (name) {
    ensureSheetAndHeaders_(spreadsheet, name, SHEET_HEADERS[name]);
  });

  const guide = DriveApp.getFileById(BOAT_PRO.GUIDE_FILE_ID);
  if (guide.getMimeType() !== MimeType.PDF) {
    throw new Error('The guide file must be a PDF.');
  }

  PropertiesService.getScriptProperties().setProperties({
    BOAT_PRO_SETUP_AT: new Date().toISOString(),
    BOAT_PRO_GUIDE_NAME: guide.getName()
  }, false);

  const result = {
    ok: true,
    spreadsheet: spreadsheet.getUrl(),
    spreadsheetTimeZone: spreadsheet.getSpreadsheetTimeZone(),
    guide: guide.getName(),
    webAppUrl: ScriptApp.getService().getUrl() || 'Deploy the web app to create its URL.'
  };

  console.log(JSON.stringify(result, null, 2));
  return result;
}

function ensureSheetAndHeaders_(spreadsheet, name, headers) {
  let sheet = spreadsheet.getSheetByName(name);
  if (!sheet) {
    sheet = spreadsheet.insertSheet(name);
  }

  const current = sheet.getRange(1, 1, 1, headers.length).getDisplayValues()[0];
  const mismatch = headers.some(function (header, index) {
    return String(current[index] || '').trim() !== header;
  });

  if (mismatch) {
    sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
  }

  sheet.setFrozenRows(1);
  sheet.getRange(1, 1, 1, headers.length)
    .setFontWeight('bold')
    .setWrap(true);
  return sheet;
}

function doPost(e) {
  const wantsJson = isJsonRequest_(e);
  try {
    const input = parseRequest_(e);
    if ((input.action || 'subscribe').toLowerCase() !== 'subscribe') {
      return json_({ ok: false, error: 'Unsupported action.' });
    }

    const result = subscribe_(input);
    return wantsJson ? json_(result) : redirectPage_(result.redirect, result.message);
  } catch (error) {
    console.error(error && error.stack ? error.stack : error);
    const message = publicError_(error);
    return wantsJson
      ? json_({ ok: false, error: message })
      : HtmlService.createHtmlOutput(
          pageHtml_('Signup needs attention', message, BOAT_PRO.SITE_URL, 'Return to Boat Pro USA')
        ).setTitle('Signup Help | Boat Pro USA');
  }
}

function doGet(e) {
  const params = (e && e.parameter) || {};
  const action = String(params.action || '').toLowerCase();

  if (action === 'unsubscribe') {
    return unsubscribe_(params);
  }

  if (action === 'health') {
    return json_({
      ok: true,
      service: 'Boat Pro USA subscriber service',
      timestamp: new Date().toISOString()
    });
  }

  return HtmlService.createHtmlOutput(
    pageHtml_(
      'Boat Pro USA',
      'The subscriber service is running.',
      BOAT_PRO.SITE_URL,
      'Visit Boat Pro USA'
    )
  ).setTitle('Boat Pro USA');
}

function subscribe_(input) {
  // Honeypot field: real visitors should leave this blank.
  if (String(input.website || input.companyWebsite || '').trim()) {
    return { ok: true, redirect: BOAT_PRO.THANK_YOU_URL };
  }

  const firstName = cleanText_(input.firstName || input.first_name || input.name, BOAT_PRO.MAX_NAME_LENGTH);
  const lastName = cleanText_(input.lastName || input.last_name, BOAT_PRO.MAX_NAME_LENGTH);
  const email = normalizeEmail_(input.email);
  const source = cleanText_(input.source || 'website', BOAT_PRO.MAX_SOURCE_LENGTH);
  const consent = parseConsent_(input.consent);

  if (!firstName) throw new UserError_('Please enter your first name.');
  if (!isValidEmail_(email)) throw new UserError_('Please enter a valid email address.');
  if (!consent) throw new UserError_('Please agree to receive the guide and Boat Pro USA emails.');

  rateLimit_(email);

  const lock = LockService.getScriptLock();
  lock.waitLock(20000);

  let delivery;
  let rowNumber;
  let token;

  try {
    const sheet = subscribersSheet_();
    const match = findSubscriber_(sheet, email);
    const now = new Date();

    if (match) {
      rowNumber = match.row;
      token = String(match.values[COL.TOKEN - 1] || Utilities.getUuid());
      const alreadySent = String(match.values[COL.GUIDE_SENT - 1]).toUpperCase() === 'YES';
      const status = String(match.values[COL.STATUS - 1]).toLowerCase();

      sheet.getRange(rowNumber, COL.FIRST, 1, 14).setValues([[
        safeCell_(firstName),
        safeCell_(lastName),
        email,
        'Active',
        safeCell_(source),
        'Yes',
        now,
        match.values[COL.SIGNUP_AT - 1] || now,
        alreadySent ? 'Yes' : 'Pending',
        match.values[COL.GUIDE_SENT_AT - 1] || '',
        token,
        '',
        now,
        ''
      ]]);

      if (alreadySent && status !== 'unsubscribed') {
        logEmail_(email, 'signup_duplicate', 'not_sent', '', 'Existing active subscriber.');
        return {
          ok: true,
          duplicate: true,
          message: 'You are already subscribed. Check your email for the guide previously sent.',
          redirect: thankYouUrl_(firstName)
        };
      }
    } else {
      token = Utilities.getUuid().replace(/-/g, '') + Utilities.getUuid().replace(/-/g, '');
      sheet.appendRow([
        Utilities.getUuid(),
        safeCell_(firstName),
        safeCell_(lastName),
        email,
        'Active',
        safeCell_(source),
        'Yes',
        now,
        now,
        'Pending',
        '',
        token,
        '',
        now,
        ''
      ]);
      rowNumber = sheet.getLastRow();
    }

    delivery = sendGuide_(firstName, email, token);

    sheet.getRange(rowNumber, COL.GUIDE_SENT).setValue('Yes');
    sheet.getRange(rowNumber, COL.GUIDE_SENT_AT).setValue(new Date());
    sheet.getRange(rowNumber, COL.UPDATED_AT).setValue(new Date());
    sheet.getRange(rowNumber, COL.ERROR).clearContent();
  } catch (error) {
    if (rowNumber) {
      const sheet = subscribersSheet_();
      sheet.getRange(rowNumber, COL.GUIDE_SENT).setValue('Failed');
      sheet.getRange(rowNumber, COL.UPDATED_AT).setValue(new Date());
      sheet.getRange(rowNumber, COL.ERROR).setValue(safeCell_(String(error.message || error).slice(0, 500)));
    }
    logEmail_(email, 'guide_delivery', 'failed', '', String(error.message || error).slice(0, 500));
    throw error;
  } finally {
    lock.releaseLock();
  }

  logEmail_(email, 'guide_delivery', 'sent', delivery.messageId || '', BOAT_PRO.GUIDE_NAME);
  recordDailySend_();

  return {
    ok: true,
    message: 'Success. Check your email for the 2026 guide.',
    redirect: thankYouUrl_(firstName)
  };
}

function sendGuide_(firstName, email, token) {
  if (MailApp.getRemainingDailyQuota() < 1) {
    throw new Error('Email service quota has been reached. Please try again tomorrow.');
  }

  const webAppUrl = ScriptApp.getService().getUrl();
  if (!webAppUrl) {
    throw new Error('The Apps Script project must be deployed as a web app before sending.');
  }

  const guide = DriveApp.getFileById(BOAT_PRO.GUIDE_FILE_ID);
  const unsubscribeUrl = webAppUrl + '?action=unsubscribe&email=' +
    encodeURIComponent(email) + '&token=' + encodeURIComponent(token);
  const safeFirst = escapeHtml_(firstName);
  const safeUnsubscribe = escapeHtml_(unsubscribeUrl);

  const subject = 'Your 2026 Annapolis Boat Shows Guide — Boat Pro USA';
  const textBody = [
    'Hi ' + firstName + ',',
    '',
    'Thank you for subscribing to Boat Pro USA.',
    '',
    "Your 2026 Annapolis Boat Shows — Do's & Don'ts Guide is attached to this email.",
    '',
    'Visit Boat Pro USA: ' + BOAT_PRO.SITE_URL,
    'Questions: ' + BOAT_PRO.SUPPORT_EMAIL,
    '',
    'Unsubscribe: ' + unsubscribeUrl,
    '',
    'Boat Pro USA',
    '650 Americana Drive',
    'Annapolis, MD 21403'
  ].join('\n');

  const htmlBody =
    '<div style="font-family:Arial,sans-serif;max-width:640px;margin:auto;color:#172638">' +
      '<div style="background:#071c33;color:#fff;padding:24px;border-bottom:5px solid #e3ad3a">' +
        '<h1 style="margin:0;font-size:26px">Boat Pro USA</h1>' +
      '</div>' +
      '<div style="padding:28px;border:1px solid #d8e0e8">' +
        '<p>Hi ' + safeFirst + ',</p>' +
        '<p>Thank you for subscribing to Boat Pro USA.</p>' +
        '<p>Your <strong>2026 Annapolis Boat Shows — Do\'s &amp; Don\'ts Guide</strong> is attached to this email.</p>' +
        '<p>Use it to prepare for the show, ask better questions, and avoid costly mistakes.</p>' +
        '<p><a href="' + BOAT_PRO.SITE_URL + '" style="display:inline-block;background:#e3ad3a;color:#071c33;padding:12px 18px;text-decoration:none;font-weight:bold;border-radius:6px">Visit Boat Pro USA</a></p>' +
        '<p>Questions? Email <a href="mailto:' + BOAT_PRO.SUPPORT_EMAIL + '">' + BOAT_PRO.SUPPORT_EMAIL + '</a>.</p>' +
      '</div>' +
      '<div style="padding:18px;color:#5b6775;font-size:12px;text-align:center">' +
        '<p>Boat Pro USA · 650 Americana Drive · Annapolis, MD 21403</p>' +
        '<p><a href="' + safeUnsubscribe + '">Unsubscribe</a></p>' +
      '</div>' +
    '</div>';

  MailApp.sendEmail({
    to: email,
    subject: subject,
    body: textBody,
    htmlBody: htmlBody,
    name: BOAT_PRO.SENDER_NAME,
    replyTo: BOAT_PRO.SUPPORT_EMAIL,
    attachments: [guide.getBlob().setName(guide.getName())]
  });

  return { messageId: Utilities.getUuid() };
}

function unsubscribe_(params) {
  const email = normalizeEmail_(params.email);
  const token = String(params.token || '').trim();
  let success = false;
  let message = 'We could not verify this unsubscribe request.';

  if (isValidEmail_(email) && token) {
    const lock = LockService.getScriptLock();
    lock.waitLock(20000);
    try {
      const sheet = subscribersSheet_();
      const match = findSubscriber_(sheet, email);
      if (match && constantTimeEqual_(String(match.values[COL.TOKEN - 1]), token)) {
        const now = new Date();
        sheet.getRange(match.row, COL.STATUS).setValue('Unsubscribed');
        sheet.getRange(match.row, COL.UNSUB_AT).setValue(now);
        sheet.getRange(match.row, COL.UPDATED_AT).setValue(now);
        unsubscribeSheet_().appendRow([now, email, safeCell_(token), 'email_link', 'success']);
        success = true;
        message = 'You have been unsubscribed from Boat Pro USA emails.';
      }
    } finally {
      lock.releaseLock();
    }
  }

  if (!success) {
    unsubscribeSheet_().appendRow([new Date(), safeCell_(email), safeCell_(token), 'email_link', 'invalid']);
  }

  return HtmlService.createHtmlOutput(
    pageHtml_(
      success ? 'You are unsubscribed' : 'Unable to unsubscribe',
      message,
      BOAT_PRO.SITE_URL,
      'Return to Boat Pro USA'
    )
  ).setTitle(success ? 'Unsubscribed | Boat Pro USA' : 'Unsubscribe Help | Boat Pro USA');
}

function parseRequest_(e) {
  if (!e) return {};
  const type = String((e.postData && e.postData.type) || '').toLowerCase();
  if (type.indexOf('application/json') !== -1 && e.postData && e.postData.contents) {
    try {
      return JSON.parse(e.postData.contents);
    } catch (error) {
      throw new UserError_('The submitted data was not valid JSON.');
    }
  }
  return e.parameter || {};
}

function isJsonRequest_(e) {
  return String((e && e.postData && e.postData.type) || '')
    .toLowerCase()
    .indexOf('application/json') !== -1;
}

function findSubscriber_(sheet, email) {
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return null;
  const values = sheet.getRange(2, 1, lastRow - 1, 15).getValues();
  for (let i = 0; i < values.length; i++) {
    if (normalizeEmail_(values[i][COL.EMAIL - 1]) === email) {
      return { row: i + 2, values: values[i] };
    }
  }
  return null;
}

function rateLimit_(email) {
  const cache = CacheService.getScriptCache();
  const key = 'signup:' + hash_(email);
  if (cache.get(key)) {
    throw new UserError_('A request for this email was submitted recently. Please check your inbox.');
  }

  const props = PropertiesService.getScriptProperties();
  const today = Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd');
  const savedDate = props.getProperty('SEND_COUNT_DATE');
  const count = savedDate === today ? Number(props.getProperty('SEND_COUNT') || 0) : 0;
  if (count >= BOAT_PRO.MAX_DAILY_SENDS) {
    throw new Error('Daily email limit reached. Please try again tomorrow.');
  }

  cache.put(key, '1', BOAT_PRO.EMAIL_COOLDOWN_SECONDS);
}

function recordDailySend_() {
  const props = PropertiesService.getScriptProperties();
  const today = Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd');
  const savedDate = props.getProperty('SEND_COUNT_DATE');
  const count = savedDate === today ? Number(props.getProperty('SEND_COUNT') || 0) : 0;
  props.setProperties({
    SEND_COUNT_DATE: today,
    SEND_COUNT: String(count + 1)
  }, false);
}

function subscribersSheet_() {
  return requiredSheet_(BOAT_PRO.SUBSCRIBERS_SHEET);
}

function unsubscribeSheet_() {
  return requiredSheet_(BOAT_PRO.UNSUBSCRIBES_SHEET);
}

function requiredSheet_(name) {
  const sheet = SpreadsheetApp.openById(BOAT_PRO.SPREADSHEET_ID).getSheetByName(name);
  if (!sheet) throw new Error('Required sheet is missing: ' + name);
  return sheet;
}

function logEmail_(email, event, status, messageId, details) {
  try {
    requiredSheet_(BOAT_PRO.EMAIL_LOG_SHEET).appendRow([
      new Date(),
      safeCell_(email),
      safeCell_(event),
      safeCell_(status),
      safeCell_(messageId),
      safeCell_(details)
    ]);
  } catch (error) {
    console.error('Unable to write email log: ' + error.message);
  }
}

function thankYouUrl_(firstName) {
  return BOAT_PRO.THANK_YOU_URL + '?name=' + encodeURIComponent(firstName);
}

function normalizeEmail_(value) {
  return String(value || '').trim().toLowerCase();
}

function isValidEmail_(email) {
  return email.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email);
}

function parseConsent_(value) {
  if (value === true || value === 1) return true;
  return ['true', 'yes', '1', 'on', 'agreed'].indexOf(String(value || '').toLowerCase()) !== -1;
}

function cleanText_(value, maxLength) {
  return String(value || '')
    .replace(/[\u0000-\u001F\u007F]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, maxLength);
}

function safeCell_(value) {
  const text = String(value == null ? '' : value);
  return /^[=+\-@]/.test(text) ? "'" + text : text;
}

function escapeHtml_(value) {
  return String(value || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function hash_(value) {
  const bytes = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, value);
  return bytes.map(function (byte) {
    const normalized = byte < 0 ? byte + 256 : byte;
    return ('0' + normalized.toString(16)).slice(-2);
  }).join('');
}

function constantTimeEqual_(a, b) {
  if (a.length !== b.length) return false;
  let mismatch = 0;
  for (let i = 0; i < a.length; i++) {
    mismatch |= a.charCodeAt(i) ^ b.charCodeAt(i);
  }
  return mismatch === 0;
}

function json_(data) {
  return ContentService
    .createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}

function redirectPage_(url, message) {
  const safeUrl = escapeHtml_(url || BOAT_PRO.THANK_YOU_URL);
  return HtmlService.createHtmlOutput(
    '<!doctype html><html lang="en"><head><meta charset="utf-8">' +
    '<meta name="viewport" content="width=device-width,initial-scale=1">' +
    '<meta http-equiv="refresh" content="0;url=' + safeUrl + '">' +
    '<title>Success | Boat Pro USA</title></head>' +
    '<body style="font-family:Arial,sans-serif;padding:32px">' +
    '<p>' + escapeHtml_(message || 'Success. Your guide is on the way.') + '</p>' +
    '<p><a href="' + safeUrl + '">Continue to Boat Pro USA</a></p>' +
    '<script>window.top.location.replace(' + JSON.stringify(url || BOAT_PRO.THANK_YOU_URL) + ');<\/script>' +
    '</body></html>'
  ).setTitle('Success | Boat Pro USA');
}

function publicError_(error) {
  if (error && error.name === 'UserError') return error.message;
  return 'We could not complete your request. Please email ' + BOAT_PRO.SUPPORT_EMAIL + '.';
}

function UserError_(message) {
  this.name = 'UserError';
  this.message = message;
}
UserError_.prototype = Object.create(Error.prototype);

function pageHtml_(title, message, url, linkText) {
  return '<!doctype html><html lang="en"><head><meta charset="utf-8">' +
    '<meta name="viewport" content="width=device-width,initial-scale=1">' +
    '<title>' + escapeHtml_(title) + '</title></head>' +
    '<body style="margin:0;background:#f4f7fa;color:#172638;font-family:Arial,sans-serif">' +
    '<main style="max-width:620px;margin:60px auto;padding:32px;background:#fff;border-top:6px solid #e3ad3a;box-shadow:0 12px 40px rgba(7,28,51,.15)">' +
    '<h1 style="color:#071c33">' + escapeHtml_(title) + '</h1>' +
    '<p>' + escapeHtml_(message) + '</p>' +
    '<p><a href="' + escapeHtml_(url) + '" style="display:inline-block;background:#071c33;color:#fff;padding:12px 18px;text-decoration:none;border-radius:5px">' +
    escapeHtml_(linkText) + '</a></p></main></body></html>';
}
