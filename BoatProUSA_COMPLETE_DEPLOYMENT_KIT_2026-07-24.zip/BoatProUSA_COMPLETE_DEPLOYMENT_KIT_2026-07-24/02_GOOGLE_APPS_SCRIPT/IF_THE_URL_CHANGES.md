# If Google Gives You a Different Apps Script URL

Editing the existing deployment should keep the current `/exec` URL. If a new URL is created:

1. Copy the entire new URL ending in `/exec`.
2. Open `04_WEBSITE_READY_TO_UPLOAD/assets/config.js` with Notepad.
3. Find the line beginning with `appsScriptUrl:`.
4. Replace only the URL between the quotation marks.
5. Save the file.
6. Upload the changed `assets/config.js` to GitHub.
7. Test the new URL with `?action=health` added to the end.
8. Submit a real signup test.

Do not use a `/dev` testing URL in the public website. Use the deployed `/exec` URL.
