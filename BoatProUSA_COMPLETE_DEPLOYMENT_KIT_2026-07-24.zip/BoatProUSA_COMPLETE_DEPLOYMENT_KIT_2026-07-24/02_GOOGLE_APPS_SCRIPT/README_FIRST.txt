BOAT PRO USA GOOGLE APPS SCRIPT

1. Use Code.gs and appsscript.json from this folder.
2. Delete Untitled 2 and all obsolete .gs files from the live Apps Script project.
3. Do not paste this code below old code. Replace old code completely.
4. Run setupBoatPro.
5. Edit the existing deployment and choose New version.
6. Test the /exec?action=health address.

The clean Code.gs contains no SHEET_NAME declaration.
