# Artifact Manifest — Canonical Files

Use these files going forward:

1. `01_INSTRUCTIONS/00_START_HERE_9TH_GRADE.md` — complete click-by-click guide.
2. `02_GOOGLE_APPS_SCRIPT/Code.gs` — canonical clean Apps Script.
3. `02_GOOGLE_APPS_SCRIPT/appsscript.json` — canonical manifest.
4. `03_GOOGLE_SHEETS/*.csv` — exact CRM header templates.
5. `04_WEBSITE_READY_TO_UPLOAD/` — canonical public website source.
6. `05_TESTING_AND_TROUBLESHOOTING/` — launch verification and repairs.

Older ZIP files named Ready, Reviewed, Repair Package, or Endpoint Configured are superseded by this complete kit. Do not mix old Apps Script files with the clean `Code.gs`.
