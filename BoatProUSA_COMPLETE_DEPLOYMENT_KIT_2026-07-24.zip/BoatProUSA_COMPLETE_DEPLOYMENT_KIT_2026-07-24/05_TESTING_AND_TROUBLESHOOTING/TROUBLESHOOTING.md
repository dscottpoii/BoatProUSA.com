# Boat Pro USA Troubleshooting

## Error: SHEET_NAME has already been declared

Cause: An old `.gs` file is still in the project or the old version is still deployed.

Fix:

1. Delete `Untitled 2`.
2. Delete every obsolete `.gs` file.
3. Keep one `Code.gs`.
4. Save.
5. Deploy > Manage deployments > Edit > New version > Deploy.
6. Retest the `/exec?action=health` URL.

## Error: Required sheet is missing

The updated setup function creates missing tabs. Confirm you used the new `Code.gs`, then run `setupBoatPro` again.

## Error: You do not have permission to call DriveApp or SpreadsheetApp

1. Run `setupBoatPro` from the editor.
2. Click Review permissions.
3. Choose the account that can edit the CRM and open the PDF.
4. Click Allow.

## Error: The guide file must be a PDF

Confirm the configured guide ID points to the actual PDF, not a Google Doc or folder.

## Health page still shows the old error

You saved the code but did not publish a new deployment version. Go to Manage deployments, edit the web app, choose New version, and deploy.

## Form opens a Google error page

1. Test the health URL first.
2. Confirm `assets/config.js` contains the correct `/exec` URL.
3. Confirm the deployment access is Anyone.
4. Confirm you used `/exec`, not `/dev`.

## Subscriber is added but no email arrives

1. Check Spam or Junk.
2. Check the `Error` column in Subscribers.
3. Check Email_Log.
4. Confirm the Apps Script account can open the PDF.
5. Confirm the daily email quota has not been reached.

## Website page shows 404

Confirm `index.html` is at the repository root, not inside an extra folder. Confirm GitHub Pages publishes `main` and `/(root)`.

## BoatProUSA.com does not open

1. Confirm the CNAME file says `BoatProUSA.com`.
2. Confirm GitHub Pages custom domain says `BoatProUSA.com`.
3. Confirm all four A records exist.
4. Confirm the www CNAME points to `dscottpoii.github.io`.
5. Remove conflicting old DNS records.

## Paid buttons do not work

This is intentional. Stripe and protected member access are not complete. Do not insert public premium file links as a shortcut.
