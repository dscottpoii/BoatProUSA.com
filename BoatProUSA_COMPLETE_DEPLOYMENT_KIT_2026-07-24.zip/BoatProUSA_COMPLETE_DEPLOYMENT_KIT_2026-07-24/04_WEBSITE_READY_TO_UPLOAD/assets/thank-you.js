(function(){
  'use strict';
  var params=new URLSearchParams(window.location.search);
  var firstName=params.get('name');
  var target=document.querySelector('.user-name');
  if(firstName&&target){target.textContent=firstName.slice(0,80);}
})();
