/* Boat Pro USA public configuration.
 * Google Apps Script production endpoint configured July 22, 2026.
 */
window.BOAT_PRO_CONFIG = Object.freeze({
  appsScriptUrl: "https://script.google.com/macros/s/AKfycbwSLD7gmeiUItt2wJVozJU1AX_2NzJwrnynRCxEvA_LhcRYIxhAtXXd1Oi2tzUImpYV8A/exec",
  supportEmail: "Info@BoatProUSA.com",
  siteUrl: "https://BoatProUSA.com",
  stripeDiyUrl: "",
  stripeCompleteUrl: ""
});
