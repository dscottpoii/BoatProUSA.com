(function(){
  'use strict';
  var config=window.BOAT_PRO_CONFIG||{};
  var toggle=document.querySelector('.nav-toggle');
  var links=document.querySelector('.nav-links');
  if(toggle&&links){toggle.addEventListener('click',function(){var open=links.classList.toggle('open');toggle.setAttribute('aria-expanded',String(open));});}
  document.querySelectorAll('[data-year]').forEach(function(el){el.textContent=new Date().getFullYear();});

  document.querySelectorAll('[data-checkout]').forEach(function(link){
    var tier=link.getAttribute('data-checkout');
    var url=tier==='diy'?config.stripeDiyUrl:config.stripeCompleteUrl;
    if(url){link.href=url;link.removeAttribute('aria-disabled');link.classList.remove('disabled');}
    else{link.href='#checkout-not-ready';link.setAttribute('aria-disabled','true');link.classList.add('disabled');link.addEventListener('click',function(e){e.preventDefault();var note=document.getElementById('checkout-not-ready');if(note){note.scrollIntoView({behavior:'smooth'});note.focus({preventScroll:true});}});}
  });

  document.querySelectorAll('form[data-newsletter-form]').forEach(function(form){
    var status=form.querySelector('.form-status');
    form.method='post';
    form.acceptCharset='UTF-8';
    if(config.appsScriptUrl){form.action=config.appsScriptUrl;}
    form.addEventListener('submit',function(event){
      status.className='form-status';
      if(!form.reportValidity()){event.preventDefault();return;}
      if(!config.appsScriptUrl){
        event.preventDefault();
        status.textContent='Signup setup is not finished yet. Add the Google Apps Script /exec URL to assets/config.js.';
        status.classList.add('error');
        return;
      }
      var submit=form.querySelector('[type="submit"]');
      submit.disabled=true;
      submit.textContent='Sending…';
      status.textContent='Submitting your request…';
    });
  });
})();
