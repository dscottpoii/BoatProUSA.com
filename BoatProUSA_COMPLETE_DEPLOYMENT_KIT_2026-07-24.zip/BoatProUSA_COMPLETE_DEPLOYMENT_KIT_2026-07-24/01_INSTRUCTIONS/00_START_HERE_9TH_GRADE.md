# Boat Pro USA — Complete Step-by-Step Deployment Guide

**Audience:** A first-time website publisher. Every important step is written out.

## What this kit does

This kit gives you:

1. A clean Google Apps Script with the duplicate declaration removed.
2. A Google Sheets CRM connection.
3. A public Boat Pro USA website ready for GitHub Pages.
4. A working free-guide signup flow after the Apps Script is redeployed.
5. Legal pages, SEO files, a thank-you page, and mobile-friendly website files.
6. Paid membership buttons that remain safely disabled until Stripe and secure login are finished.

## Important status before you begin

The website files are configured to use this Google Apps Script address:

`https://script.google.com/macros/s/AKfycbwSLD7gmeiUItt2wJVozJU1AX_2NzJwrnynRCxEvA_LhcRYIxhAtXXd1Oi2tzUImpYV8A/exec`

The code inside this kit is clean. However, the live address still showed the old error on **July 24, 2026**:

`SyntaxError: Identifier 'SHEET_NAME' has already been declared (line 1, file "Untitled 2")`

That means the code was fixed in the package, but Google is still serving an older deployed version. You must complete **Part 2** and choose **New version** when redeploying.

---

# Part 1 — Download and open the kit

## Step 1: Download the ZIP

1. Download `BoatProUSA_COMPLETE_DEPLOYMENT_KIT_2026-07-24.zip`.
2. Look in your computer's **Downloads** folder.
3. Find the ZIP file.

## Step 2: Extract the ZIP

On Windows:

1. Right-click the ZIP file.
2. Click **Extract All**.
3. Leave the suggested folder name in place.
4. Click **Extract**.
5. Wait for the new folder to open.

Do not try to edit files while they are still inside the ZIP.

## Step 3: Understand the folders

Open the extracted folder. You will see:

- `01_INSTRUCTIONS` — the instructions you are reading.
- `02_GOOGLE_APPS_SCRIPT` — the clean server code.
- `03_GOOGLE_SHEETS` — exact CRM column templates.
- `04_WEBSITE_READY_TO_UPLOAD` — only the files that belong in the website repository.
- `05_TESTING_AND_TROUBLESHOOTING` — final tests and common fixes.
- `06_REFERENCE_ARTIFACTS` — updated supporting files from earlier work.

**Do not upload the whole deployment-kit folder to GitHub.** Later, you will upload only the contents of `04_WEBSITE_READY_TO_UPLOAD`.

---

# Part 2 — Fix and redeploy Google Apps Script

## Goal of this part

You will replace the old Apps Script files with one clean `Code.gs` file and redeploy the existing web app. Editing the existing deployment keeps the same `/exec` address.

## Step 1: Sign in to the correct Google account

1. Open a new browser tab.
2. Go to `https://script.google.com/`.
3. Sign in with the Google account that can open both:
   - The Boat Pro USA Subscriber CRM spreadsheet.
   - The 2026 Annapolis Boat Shows PDF.
4. If you are signed into several Google accounts, check the profile picture in the upper-right corner and select the correct account.

The script must be able to **edit the spreadsheet** and **read the PDF**.

## Step 2: Open the existing Apps Script project

1. On the Apps Script home screen, look under **My Projects**.
2. Open the Boat Pro USA subscriber or newsletter project.
3. If you do not know which project is correct, open the project that contains a file named **Untitled 2** or code containing `SHEET_NAME`.
4. When the project opens, look at the file list on the left side.

Do not create a new project unless you truly cannot locate the old one. A new project creates a different `/exec` address.

## Step 3: Delete the old duplicate files

1. In the left file list, find **Untitled 2**.
2. Move your mouse over the file name.
3. Click the three-dot menu beside the file.
4. Click **Delete**.
5. Confirm the deletion.
6. Repeat this for every old `.gs` file except one file that you will keep as `Code.gs`.
7. You should end with one `.gs` file named `Code.gs`.

Important: Do not paste the new code below old code. Replace the old code completely.

## Step 4: Replace Code.gs

1. Return to the extracted deployment kit.
2. Open `02_GOOGLE_APPS_SCRIPT`.
3. Open `Code.gs` with Notepad or another plain-text editor.
4. Press **Ctrl+A** to select all the code.
5. Press **Ctrl+C** to copy it.
6. Return to the Apps Script browser tab.
7. Click `Code.gs` in the left file list.
8. Click inside the code editor.
9. Press **Ctrl+A** to select all old code.
10. Press **Backspace** or **Delete**.
11. Press **Ctrl+V** to paste the clean code.
12. Press **Ctrl+S** to save.

## Step 5: Show the manifest file

1. In Apps Script, click the gear icon labeled **Project Settings** on the left.
2. Find **Show "appsscript.json" manifest file in editor**.
3. Turn that setting on.
4. Click the editor icon on the left to return to the file list.
5. You should now see `appsscript.json`.

## Step 6: Replace appsscript.json

1. In the deployment kit, open `02_GOOGLE_APPS_SCRIPT/appsscript.json`.
2. Press **Ctrl+A**, then **Ctrl+C**.
3. Return to Apps Script.
4. Click `appsscript.json`.
5. Press **Ctrl+A** inside the editor.
6. Press **Backspace** or **Delete**.
7. Press **Ctrl+V**.
8. Press **Ctrl+S**.

## Step 7: Run the setup function

The setup function checks the spreadsheet and PDF, creates missing sheet tabs if necessary, repairs the header row, adds the missing **Status** header to the Unsubscribes tab, freezes row 1, and sets the spreadsheet time zone to America/New_York.

1. At the top of the Apps Script editor, find the function dropdown.
2. Click the dropdown.
3. Select `setupBoatPro`.
4. Click **Run**.
5. Google may ask for permission.
6. Click **Review permissions**.
7. Choose the correct Google account.
8. If Google displays an “unverified” warning for your own script, click **Advanced**.
9. Click the option to continue to the Boat Pro project.
10. Click **Allow**.
11. Wait until the execution status says **Execution completed**.

If it says **Execution failed**, open `05_TESTING_AND_TROUBLESHOOTING/TROUBLESHOOTING.md` and match the error message.

## Step 8: Redeploy the existing web app

This is the step that makes the fixed code live.

1. In Apps Script, click **Deploy** in the upper-right corner.
2. Click **Manage deployments**.
3. Find the existing deployment marked **Web app**.
4. Click the pencil icon to edit it.
5. Find **Version**.
6. Choose **New version**. Do not leave it on the old version.
7. Enter this description: `Boat Pro clean subscriber service - July 24 2026`.
8. Set **Execute as** to **Me**.
9. Set **Who has access** to **Anyone**.
10. Click **Deploy**.
11. Approve permissions again if Google asks.
12. Copy the web app URL ending in `/exec`.
13. Compare it with the configured address shown at the top of this guide.

When you edit the existing deployment, the address should stay the same. If Google gives you a different address, follow the fallback instructions in `02_GOOGLE_APPS_SCRIPT/IF_THE_URL_CHANGES.md` before uploading the website.

## Step 9: Test the health address

1. Open a new browser tab.
2. Paste this exact address:

`https://script.google.com/macros/s/AKfycbwSLD7gmeiUItt2wJVozJU1AX_2NzJwrnynRCxEvA_LhcRYIxhAtXXd1Oi2tzUImpYV8A/exec?action=health`

3. Press **Enter**.
4. A working service should display text containing:

`"ok":true`

5. It should also contain:

`"service":"Boat Pro USA subscriber service"`

Do not continue to the public signup test until this health check works.

---

# Part 3 — Check the Google Sheets CRM

## Step 1: Open the CRM

Open:

`https://docs.google.com/spreadsheets/d/13XSLWLfjOmSd9KhvW7BoS1SNaHbCgMgvAJSCQofZz1g/edit`

The spreadsheet title should be **Boat Pro USA Subscriber CRM**.

## Step 2: Check the three tabs

At the bottom, confirm these exact tab names exist:

1. `Subscribers`
2. `Email_Log`
3. `Unsubscribes`

Do not add spaces, change capitalization, or rename these tabs.

## Step 3: Check the Subscribers header row

Click the `Subscribers` tab. Row 1 should contain these 15 headings from A1 through O1:

1. Subscriber ID
2. First Name
3. Last Name
4. Email
5. Status
6. Source
7. Consent
8. Consent Timestamp
9. Signup Timestamp
10. Guide Sent
11. Guide Sent Timestamp
12. Unsubscribe Token
13. Unsubscribe Timestamp
14. Last Updated
15. Error

## Step 4: Check Email_Log

Click `Email_Log`. Row 1 should contain:

1. Timestamp
2. Email
3. Event
4. Status
5. Message ID
6. Details

## Step 5: Check Unsubscribes

Click `Unsubscribes`. Row 1 should contain:

1. Timestamp
2. Email
3. Token
4. Source
5. Status

The older sheet had only four headings. Running `setupBoatPro` adds the fifth heading, **Status**, without deleting subscriber data.

## Step 6: Check spreadsheet time zone

1. In Google Sheets, click **File**.
2. Click **Settings**.
3. Confirm the time zone is an Eastern Time setting for New York.
4. If it is not, select **(GMT-05:00) Eastern Time – New York** or the closest New York option.
5. Click **Save and reload**.

The setup function also attempts to set `America/New_York` automatically.

---

# Part 4 — Check the free guide PDF

## Step 1: Open the guide

Open:

`https://drive.google.com/file/d/1lKNfxDKJxN-zOeXcmiVevKvSPZj2GopP/view`

The file should be named:

`2026 Annapolis Boat Shows - Do's & Don'ts Guide - The Boat Pro.pdf`

## Step 2: Confirm it is a PDF

1. Make sure the file opens as a PDF.
2. Make sure the guide pages display correctly.
3. Make sure the Google account deploying Apps Script can open it.

## Step 3: Restrict the direct Drive link

The script emails the PDF as an attachment. The PDF does not need to be public.

1. Click **Share**.
2. Under **General access**, choose **Restricted**.
3. Make sure the Apps Script owner still has access.
4. Click **Done**.

This stops a permanent public Drive link from becoming the main delivery method.

---

# Part 5 — Upload the website to GitHub

## Repository information

- GitHub repository: `dscottpoii/BoatProUSA.com`
- Branch: `main`
- Custom domain: `BoatProUSA.com`

## Step 1: Back up the current repository

1. Open `https://github.com/dscottpoii/BoatProUSA.com`.
2. Sign in to GitHub.
3. Click the green **Code** button.
4. Click **Download ZIP**.
5. Keep that backup in your Downloads folder.

## Step 2: Open the correct source folder on your computer

1. Return to the extracted deployment kit.
2. Open `04_WEBSITE_READY_TO_UPLOAD`.
3. Confirm you can see `index.html` and the `assets` folder.

You must upload the files **inside** this folder. Do not upload the folder itself as one extra level.

## Step 3: Upload the new files

1. Return to the GitHub repository page.
2. Confirm the branch dropdown says `main`.
3. Click **Add file**.
4. Click **Upload files**.
5. Open the `04_WEBSITE_READY_TO_UPLOAD` folder in Windows File Explorer.
6. Press **Ctrl+A** to select every file and folder inside it.
7. Drag the selected items into the GitHub upload box.
8. Wait until GitHub lists all uploaded files.
9. Scroll to **Commit changes**.
10. In the message box, enter: `Deploy clean Boat Pro USA 2026 website`.
11. Choose **Commit directly to the main branch**.
12. Click **Commit changes**.

Important: Uploading new files replaces files with the same names, but it does not automatically delete unrelated old files. Review the repository afterward and remove any old premium PDF, workbook, tutorial, or direct-download file that should not remain public.

## Step 4: Check the repository root

After the commit, the first page of the repository should show:

- `index.html`
- `about.html`
- `guides.html`
- `members.html`
- `privacy.html`
- `terms.html`
- `refund-policy.html`
- `thank-you.html`
- `CNAME`
- `robots.txt`
- `sitemap.xml`
- `assets` folder

If all files appear inside an extra folder, the website will not find `index.html`. Move them to the repository root.

---

# Part 6 — Turn on GitHub Pages

1. On the GitHub repository page, click **Settings**.
2. In the left menu, click **Pages**.
3. Under **Build and deployment**, set **Source** to **Deploy from a branch**.
4. Set the branch to `main`.
5. Set the folder to `/ (root)`.
6. Click **Save**.
7. In **Custom domain**, enter `BoatProUSA.com`.
8. Click **Save**.
9. Leave **Enforce HTTPS** unchecked only while GitHub is creating the certificate.
10. Return later and check **Enforce HTTPS** after GitHub allows it.

The repository already contains a `CNAME` file with `BoatProUSA.com`.

---

# Part 7 — Set the domain DNS records

Open the website where the BoatProUSA.com domain was purchased. This may be GoDaddy, Namecheap, Squarespace Domains, Cloudflare, or another registrar.

## Add four A records for the main domain

Create these four records:

| Type | Name/Host | Value |
|---|---|---|
| A | @ | 185.199.108.153 |
| A | @ | 185.199.109.153 |
| A | @ | 185.199.110.153 |
| A | @ | 185.199.111.153 |

Use the default TTL if the registrar asks for one.

## Add one CNAME record for www

| Type | Name/Host | Value |
|---|---|---|
| CNAME | www | dscottpoii.github.io |

Remove conflicting old A records or a conflicting `www` record. Do not create a wildcard `*` record.

---

# Part 8 — Test the complete signup flow

Use a real email address that is not already listed in the Subscribers tab.

## Test 1: Website pages

Open `https://BoatProUSA.com/` and check:

1. The logo appears.
2. The menu works.
3. Guides opens.
4. DIY Tutorials opens.
5. Newsletters opens.
6. Membership opens.
7. About opens.
8. Privacy, Terms, and Refund Policy open.
9. The site works on a phone.

## Test 2: Free-guide form

1. Go to the homepage.
2. Scroll to **Get the 2026 Annapolis Boat Shows Guide**.
3. Enter a first name.
4. Enter a last name.
5. Enter a new test email address.
6. Check the consent box.
7. Click **Email My Free Guide**.
8. Confirm the browser reaches `https://BoatProUSA.com/thank-you.html`.

## Test 3: CRM row

1. Open the Google Sheet.
2. Open `Subscribers`.
3. Look at the newest row.
4. Confirm the email is correct.
5. Confirm Status says `Active`.
6. Confirm Consent says `Yes`.
7. Confirm Guide Sent says `Yes`.
8. Confirm the Error cell is blank.

## Test 4: Email delivery

1. Open the test email inbox.
2. Check Spam or Junk if necessary.
3. Open the Boat Pro USA email.
4. Confirm the 2026 guide is attached.
5. Confirm the support email is `Info@BoatProUSA.com`.
6. Confirm the mailing address is shown.

## Test 5: Email log

1. Open the `Email_Log` tab.
2. Confirm a `guide_delivery` event appears.
3. Confirm its status says `sent`.

## Test 6: Unsubscribe

1. Click the unsubscribe link in the test email.
2. Confirm the browser says the address is unsubscribed.
3. Return to the `Subscribers` tab.
4. Confirm Status changed to `Unsubscribed`.
5. Confirm Unsubscribe Timestamp is filled in.
6. Open the `Unsubscribes` tab.
7. Confirm the test appears with Status `success`.

## Test 7: Duplicate signup

1. Submit the same test email again.
2. Confirm the system does not send unlimited duplicate copies.
3. Confirm the CRM does not create unnecessary duplicate rows.

---

# Part 9 — What must remain disabled

Do not enable the $19.99 DIY or $24.99 Complete checkout buttons yet.

Before paid membership can launch, you still need:

1. Real Stripe Checkout links.
2. Stripe webhook signature verification.
3. A secure database or verified membership status.
4. Passwordless email login or secure one-time links.
5. Server-side access checks.
6. Protected downloads that do not reveal permanent public file URLs.
7. Cancellation and renewal processing.

The current site intentionally displays paid options without working checkout links. This is safer than collecting payment before access control is ready.

---

# Final launch rule

The free subscriber website is ready to promote only after all four items below are true:

- [ ] The Apps Script health page contains `"ok":true`.
- [ ] A new test subscriber appears in Google Sheets.
- [ ] The test email receives the correct PDF attachment.
- [ ] The unsubscribe link changes the CRM status.

Keep this guide with your Boat Pro USA records.
