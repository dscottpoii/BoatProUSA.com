# Boat Pro USA CRM Verification

Verified spreadsheet:

- Title: `Boat Pro USA Subscriber CRM`
- Spreadsheet ID: `13XSLWLfjOmSd9KhvW7BoS1SNaHbCgMgvAJSCQofZz1g`
- Required tabs: `Subscribers`, `Email_Log`, `Unsubscribes`

The Subscribers and Email_Log headers matched the clean script. The Unsubscribes tab originally had four headings while the script records five values. The updated setup function repairs row 1 by adding `Status` in column E.

Do not rename the tabs. The clean setup function will not delete rows below the header.
